var synth = window.speechSynthesis;

var textToSpeak = '';
var output = document.getElementById('label');

const noun1Btn = document.getElementById("noun1");
const verbBtn = document.getElementById("verb");
const adjectiveBtn = document.getElementById("adjective");
const noun2Btn = document.getElementById("noun2");
const settingBtn = document.getElementById("setting");
const speakButtonBtn = document.getElementById("speakButton");

var nouns = ['The Turkey', 'Mom', 'Dad', 'The Dog', 'My teacher', 'The elephant', 'The cat'];
var verbs = ["sat on", "ate", "danced with", "saw", "doesn't like", "kissed"];
var adjectives = ["a funny", "a scary", "a goofy", "a slimy", "a barking", "a fat"];
const noun2 = ["goat", "monkey", "fish", "cow", "frog", "bug", "worm"];
var places = ["on the moon.", "on the chair.", "in my spaghetti.", "in my soup.", "on the grass.", "in my shoes."];

/* Functions
-------------------------------------------------- */
function getRandomElement(array) {
    return array[Math.floor(Math.random() * array.length)];
}

function speakNow(string) {
    var utterThis = new SpeechSynthesisUtterance(string);
    synth.speak(utterThis);
}

/* Event Listeners
-------------------------------------------------- */
noun1Btn.onclick = function() {
    var randomNoun = getRandomElement(nouns);
    textToSpeak += randomNoun + ' ';
    output.textContent = textToSpeak;
}

verbBtn.onclick = function() {
    var randomVerb = getRandomElement(verbs);
    textToSpeak += randomVerb + ' ';
    output.textContent = textToSpeak;
}

adjectiveBtn.onclick = function() {
    var randomAdjective = getRandomElement(adjectives);
    textToSpeak += randomAdjective + ' ';
    output.textContent = textToSpeak;
}

noun2Btn.onclick = function() {
    var randomObject = getRandomElement(noun2);
    textToSpeak += randomObject + ' ';
    output.textContent = textToSpeak;
}

settingBtn.onclick = function() {
    var randomPlace = getRandomElement(places);
    textToSpeak += randomPlace + ' ';
    output.textContent = textToSpeak;
}

speakButton.onclick = function() {
    speakNow(textToSpeak);
    textToSpeak = '';
    output.textContent = '';
}